# My-Works
My Work-In-Progress Works, will keep this organized.

#BlockImageLoader
A Generator of 3D inventory model of blocks
By Affogatoman,
#
Made top, left, right textures into a new bitmap with transparent space. I haven't tested this yet but you could try by doing:
importing it in a texture pack and adding this to your script

 eval("" + new java.lang.String("textures/<your directory>/<Block Image Loader JS file>") + ""),
or local directory (add to script):
 
//(i don't know if apache commons is installed indefault in android)
 eval(""+ org.apache.commons.io.FileUtils.readFileToString(<directory> /BlockImageLoader.js) +"")
 
 // if not, use this instead,
 eval("" + new java.lang.String(Files.readAllBytes(Paths.get("<directory>"))) + "")
original link:
https://github.com/if-Team/ModPE-Scripts/tree/master/BlockImageLoader
