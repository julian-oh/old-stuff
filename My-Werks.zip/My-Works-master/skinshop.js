//Skin shop

var ShopData = {
	player:{
		unlocked:{}
		bought:{},
	},
	lore:{
		skins:{
			soulBox:{
				christmas:["Give the soul some Holiday break from suffering", "Storing the Christmas Spirits in a Jolly Way"],
				halloween:["APPOPRIATE!", "It's their hollyday"]
				default:["Missed this?"]
			},
			souls:{
				paperBag:["Scared?, Well a Paper Bag won't fix it", "Vomit?"],
				christmas:["Peeping in your chimney since the date in their grave", "Made of Snow", "Gives your hollyday some chill"],
				halloween:["Uhmmm"],
				invisible:["Why?"],
				default:["Missed this?"]
			},
			creeper:{
				skeleton:["Oh he's not scary enough?"]
			}
		}
	}
}