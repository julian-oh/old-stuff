# ModPEAPIs
My JavaScript APIs for ModPE. Feel free to use them without credits but I would appreciate if you put my name in your mod :)

This is currently work in progress and I'll try to document it as best as I can 
