# DevInAndroid

This repo is for the projects that I make that could help making games (or programs) in **Android** much easier

Check out *AIDE*, the application I use to program LibGDX games:
> https://play.google.com/store/apps/details?id=com.aide.ui

**LibGDX Texture Packer**
- It simply packs a folder of images into a TextureAtlas file.
